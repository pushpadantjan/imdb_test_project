package com.imdbTestProject.webRunner;

import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Managed;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import com.imdbTestProject.webTestSteps.*;

@RunWith(SerenityRunner.class)
public class webrunner {

    @Managed(driver = "chrome")
    WebDriver driver;

    @Test
    public void testScenario1() {
        imdbTestSteps givenUserhaveOpenedIMDBWebPage;
        imdbTestSteps whenUserClickedOnMenuTopRatesTVShows;
        imdbTestSteps thenUserVerifySearchResultTopRatedTVShows;

    }

    @Test
    public void testScenario2(){

        imdbTestSteps givenUserhaveOpenedIMDBWebPage;
        imdbTestSteps whenUserSearchGameOfThroneShow;
        imdbTestSteps thenUserVerifyGameOfThroneSearchResult;
    }

    @Test
    public void testScenario3(){

        imdbTestSteps givenUserhaveOpenedIMDBWebPage;
        imdbTestSteps givenUserSettvshow;
        imdbTestSteps givenUserSetRating;
        imdbTestSteps givenUserSetNoofReviews;
        imdbTestSteps whenUserClickedOnMenuTopRatesTVShows;
        imdbTestSteps whenUserClicksTVshow;
        imdbTestSteps thenUserVerifyTVShow;
        imdbTestSteps thenUserVerifyRating;
        imdbTestSteps thenUserVerifyNoOfReviews;
    }

    @Test
    public void testScenario4(){
        imdbTestSteps givenUserHaveOpenGmail;
        imdbTestSteps givenUserhaveOpenedIMDBWebPage;
        imdbTestSteps givenUserSetCustomerName;
        imdbTestSteps givenUserSetemail;
        imdbTestSteps givenUserSetPassword;
        imdbTestSteps givenUserSetReEnterPassword;
        imdbTestSteps whenUserNavigatesCreateUserInputPage;
        imdbTestSteps whenUserEntersName;
        imdbTestSteps whenUserEntersEmail;
        imdbTestSteps whenUserEntersPassword;
        imdbTestSteps whenUserEntersReEnterPassword;
        imdbTestSteps whenUserClicksLoginButton;
        imdbTestSteps andUserEntersOTPImdbClickSubmitButton;
        imdbTestSteps thenUserHaveCreateSuccessfully;
    }

    @Test
    public void testScenario5(){
        imdbTestSteps givenUserHaveOpenGmail;
        imdbTestSteps givenUserSetemail;
        imdbTestSteps givenUserSetPassword;
        imdbTestSteps whenUserNavigatesLoginPage;
        imdbTestSteps whenUserEntersEmail;
        imdbTestSteps whenUserEntersPassword;
        imdbTestSteps whenUserClicksLoginButton;
        imdbTestSteps thenUserLoggedInSuccessfully;
    }
}
