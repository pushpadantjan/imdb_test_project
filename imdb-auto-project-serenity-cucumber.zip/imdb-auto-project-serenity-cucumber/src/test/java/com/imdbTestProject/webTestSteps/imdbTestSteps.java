package com.imdbTestProject.webTestSteps;

import com.imdbTestProject.webPage.imdbPage;
import com.imdbTestProject.testData.imdbTestData;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.steps.ScenarioSteps;
import org.hamcrest.Matchers;
import static org.hamcrest.MatcherAssert.assertThat;

import java.util.List;

public class imdbTestSteps extends ScenarioSteps {

    private imdbPage imdb;

// Question 1

    @Given("User have opened IMDB webpage")
    public void givenUserhaveOpenedIMDBWebPage(){
        imdbPage openIMDB;
    }

    @When("User clicked on Menu >> Top Rated TV shows")
    public void whenUserClickedOnMenuTopRatesTVShows(){
        imdbPage searchTopTVShows;
    }

    @Then("User verify the search result of Top Rated TV shows")
    public void thenUserVerifySearchResultTopRatedTVShows(){
       imdbPage getTopTVShows;
    }

    @Then("User verify the ratings of Top rated TV shows")
    public void thenUserVerifyRatingTopRatedTVShows(){
        imdbPage rating;
    }

    @When("User search Game of Throne show")
    public void whenUserSearchGameOfThroneShow(){
        imdbPage searchByKeyword;
    }

    @Then("User verify the Game of thrones search result")
    public void thenUserVerifyGameOfThroneSearchResult(){
        List<String> list = imdb.getShowsFromSearch();
        for (int i = 0; i < list.size(); i++){
            System.out.println(list.get(i).toLowerCase());
            assertThat(list.get(i).toLowerCase(), Matchers.containsString(imdbTestData.getGameOfThrone().toLowerCase()));
        }
    }

    @Given("User set tvshow to <TVShow>")
    public void givenUserSettvshow(String value){
        imdbTestData.setTopTVShows(value);
    }

    @Given("User set rating to <Rating>")
    public void givenUserSetRating(String value){
        imdbTestData.setRating(value);
    }

    @Given("User set noofreviews to <NoOfReviews>")
    public void givenUserSetNoofReviews(String value){
        imdbTestData.setNoOfReviews(value);
    }

    @When("User clicks on TVShow on Top Rated TV shows")
    public void whenUserClicksTVshow(){
    imdbPage PlanetEarthII;
    }

    @Then("User verify TVShow")
    public void thenUserVerifyTVShow(){
        String tvshow = imdb.getheader();
         assertThat(imdb.getheader(), Matchers.containsString(imdbTestData.getTopTVShows()));
         imdbPage planetearhheader;
    }

    @Then("User verify Rating")
    public void thenUserVerifyRating(){
        String tvshowrating = imdb.PlanetEarthrating();
        assertThat(imdb.PlanetEarthrating(), Matchers.containsString(imdbTestData.getRating()));
        imdbPage planetearthrating;
    }

    @Then("user verify NoOfReviews")
    public void thenUserVerifyNoOfReviews(){
        String tvshowNoOfReviews = imdb.PlanetEarthReviews();
        assertThat(imdb.PlanetEarthReviews(), Matchers.containsString(imdbTestData.getNoOfReviews()));
        imdbPage planetearthnoreviews;
    }



 // Question 2

 @Given("User have opened Gmail webpage")
 public void givenUserHaveOpenGmail(){
        imdbPage gmailURL;
 }

 @Given("User set email to <Email>")
 public void givenUserSetemail(String value){
        imdbTestData.setEmailID(value);
    }
 @Given("User set password to <Password>")
 public void givenUserSetPassword(String value){
        imdbTestData.setPassword(value);
 }

 @Given("User set reEnterPassword to <ReEnterPassword>")
 public void givenUserSetReEnterPassword(String value){
        imdbTestData.setReEnterpassword(value);
 }

@Given("User set customername to <Name>")
public void givenUserSetCustomerName(String value){
        imdbTestData.setName(value);
}

 @When("User navigates to create user input page")
 public void whenUserNavigatesCreateUserInputPage(){
        imdbPage navigateToCreateUser;
 }

 @When("User enters Name")
 public void whenUserEntersName(){
        imdbPage customerName;
 }
 @When("User enters email")
 public void whenUserEntersEmail(){
        imdbPage enterEmail;
 }

 @When("User enters Password")
 public void whenUserEntersPassword(){
        imdbPage enterPassword;
 }

 @When("User enters reEnterPassowrd")
 public void whenUserEntersReEnterPassword(){
        imdbPage reEnterPassword;
 }

 @When("User navigates to login page")
 public void whenUserNavigatesLoginPage(){
        imdbPage signInIDB;
 }

 @When("User clicks on Login button")
 public void whenUserClicksLoginButton(){
        imdbPage loginButton;

 }

 @When("User enters key details in create input page")
 public void whenUserEntersKeyDetailsCreateInputPage(){
        imdbPage createNewImdbUser;
        String parent = getDriver().getWindowHandle();
     System.out.println("Parent Window" +parent);
     imdbPage getImdbOtpFromGmail;
     getDriver().switchTo().window(parent);
    imdbPage enterOTP;
 }

    private String getAllWindows(String allWindows) {
        return allWindows;
    }

    @And("User enters OTP in IMDB and clicks on Submit button")
    public void andUserEntersOTPImdbClickSubmitButton(){
        imdbPage enterOTP;
 }

 @Then("User have created successfully")
    public void thenUserHaveCreateSuccessfully(){
    imdbPage signInIDB;

 }

 @Then("User logged in successfully")
    public void thenUserLoggedInSuccessfully(){
        imdbPage signInIDB;

 }

}
