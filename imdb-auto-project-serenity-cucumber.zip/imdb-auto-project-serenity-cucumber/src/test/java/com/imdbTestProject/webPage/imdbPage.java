package com.imdbTestProject.webPage;


import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
import com.imdbTestProject.testData.imdbTestData;

import java.util.ArrayList;
import java.util.List;


@DefaultUrl("https://www.google.com/")
public class imdbPage extends PageObject {

    private static String getheader;
    private static String PlanetEarthrating;
    private static String PlanetEarthReviews;

    @FindBy(xpath = "//label[@id='imdbHeader-navDrawerOpen--desktop']")
    WebElementFacade MainMenu;

    @FindBy(xpath = "(//label[@aria-label='Expand TV Shows Nav Links']/..//a[@role='menuitem'])[3]")
    WebElementFacade TopTVShow;

    @FindBy(xpath = "//tbody[@class='lister-list']")
    List<WebElementFacade> TVShows;

    @FindBy(xpath = "//input[@type='text']")
    WebElementFacade SearchBox;

    @FindBy(xpath = "//button[@type='submit']")
    WebElementFacade SearchButton;

    @FindBy(xpath = "(//table[@class='findList'])[1]")
    List<WebElementFacade> ListFromSearch;

    @FindBy(xpath = "//strong[@title='9.5 based on 101,742 user ratings']")
    WebElementFacade Rating;

    @FindBy(xpath = "//div[contains(text(),'Sign In')]")
    WebElementFacade signIn;

    @FindBy(xpath = "//a[contains(text(),'Create a New Account')]")
    WebElementFacade createNewAccount;

    @FindBy(xpath = "//input[@id='ap_customer_name']")
    WebElementFacade customerName;

    @FindBy(xpath = "//input[@id='ap_email']")
    WebElementFacade emailID;

    @FindBy(xpath = "//input[@id='ap_password']")
    WebElementFacade password;

    @FindBy(xpath = "//input[@id='ap_password_check']")
    WebElementFacade reEnterPassword;

    @FindBy(xpath = "//input[@type='submit']")
    WebElementFacade submitButton;

    @FindBy(xpath = "//input[@type='text']")
    WebElementFacade OTP;

    @FindBy(xpath = "//div[contains(text(),'Use another account')]")
    WebElementFacade gmailAnotherUser;

    @FindBy(xpath = "//input[@type='email']")
    WebElementFacade gmailUser;

    @FindBy(xpath = "//span[contains(text(),'Next')]")
    WebElementFacade gmailNext;

    @FindBy(xpath = "//div[@id='password']")
    WebElementFacade gmailPassword;

    @FindBy(xpath = "//span[contains(text(),'Verify your new IMDb account')]")
    WebElementFacade gmailMessage;

    @FindBy(xpath = "//p[@class='m_2957294180229889057otp']")
    WebElementFacade gmailOTP;

    @FindBy(xpath = "//span[contains(text(),'Sign in with IMDb')]")
    WebElementFacade signInWithIMDB;

    @FindBy(xpath = "(//span[contains(text(),'tester')])[1]")
    WebElementFacade signInToIMDB;

    @FindBy(xpath = "//a[contains(text(),'Planet Earth II')]")
    WebElementFacade PlanetEarthII;

    @FindBy(xpath = "//h1[contains(text(),'Planet Earth II')]")
    WebElementFacade PlanetEarthHeader;

    @FindBy(xpath = "(//span[contains(text(),'9.5')])[1]")
    WebElementFacade PlanetEarthIIRating;

    @FindBy(xpath = "//span[@itemprop='ratingCount']")
    WebElementFacade PlanetEarthIIRatingCount;

    public void openIMDB() {
        openUrl("https://www.imdb.com/");
    }

    public void gmailURL() { openUrl("https://www.gmail.com/");}

    public void searchTopTVShows(){
        MainMenu.click();
        TopTVShow.click();
    }

    public List<String> getTopTVShows(){

        List<String> toptvshowlist = new ArrayList<>();
        for (int i = 0; i < TVShows.size(); i++){
            toptvshowlist.add(TVShows.get(i).getText());
        }
        return toptvshowlist;
    }

    public void searchByKeyword(){
        SearchBox.click();
        SearchBox.typeAndEnter("Game of thrones");
        SearchButton.click();
    }

    public List<String> getShowsFromSearch(){
        List<String> searchlist = new ArrayList<>();
        for (int i = 0; i < ListFromSearch.size(); i++){
            searchlist.add(ListFromSearch.get(i).getText());

        }
        return searchlist;
    }
    public void rating(){
        Rating.isDisplayed();
    }

    public void PlanetEarthII(){
        PlanetEarthII.click();
    }

    public String getheader(){
        PlanetEarthHeader.getText();
        return null;
    }
    public void planetearhheader(){
        PlanetEarthHeader.isDisplayed();
    }
    public void planetearthrating(){
        PlanetEarthIIRating.isDisplayed();
    }

    public void planetearthnoreviews(){
        PlanetEarthIIRatingCount.isDisplayed();
    }


    public String PlanetEarthrating(){
        PlanetEarthIIRating.getText();
        return null;
    }

    public String PlanetEarthReviews(){
        PlanetEarthIIRatingCount.getText();
        return null;
    }


    public String getImdbOtpFromGmail(){
        gmailURL();
        gmailAnotherUser.click();
        gmailUser.typeAndEnter("testerimdb1");
        gmailNext.click();
        gmailPassword.typeAndEnter("Test@1234");
        gmailMessage.click();
       String imdbOTP = gmailOTP.getText();
        System.out.println(gmailOTP.getText());
        return imdbOTP;
    }

    public void navigateToCreateUser(){
        signIn.click();
        createNewAccount.click();
    }

    public void customerName(){
        customerName.click();
        customerName.typeAndEnter(imdbTestData.getName());

    }
    public void enterEmail(){
        emailID.click();
        emailID.typeAndEnter(imdbTestData.getEmailID());
    }
    public void enterPassword(){
        password.click();
        password.typeAndEnter(imdbTestData.getPassword());
    }

    public void reEnterPassword(){
        reEnterPassword.click();
        reEnterPassword.typeAndEnter(imdbTestData.getReEnterpassword());
    }

    public void loginButton(){
        submitButton.click();
    }



    public void enterOTP(){

        OTP.typeAndEnter(getImdbOtpFromGmail().toString());
        submitButton.click();
    }

    public void signInNewUser() {
        signIn.click();
        signInWithIMDB.click();
        emailID.typeAndEnter(imdbTestData.getPassword());
        password.typeAndEnter(imdbTestData.getPassword());
        submitButton.click();
    }

    public void signInIDB(){
        signInToIMDB.click();
    }


}
