package com.imdbTestProject.testData;

public class imdbTestData {

    private static String TVShow;
    private static String gameOfThroneShows;
    private static String Rating;
    private static String NoOfReviews;

    private static String username;
    private static String emailID;
    private static String password;
    private static String reEnterpassword;
    private static String name;

    public static String getTopTVShows(){

        return TVShow;
    }

    public static String getGameOfThrone(){

        return gameOfThroneShows;
    }

    public static void setTopTVShows(String TVShow){
        imdbTestData.TVShow = TVShow;
    }


    public static void setGameOfThrone(String gameOfThrone){
        imdbTestData.gameOfThroneShows = gameOfThrone;
    }

    public static String getRating(){
        return Rating;
    }

    public static void setRating(String rating){
        imdbTestData.Rating = rating;
    }

    public static String getNoOfReviews(){

        return NoOfReviews;
    }

    public static void setNoOfReviews(String noOfReviews){
        imdbTestData.NoOfReviews = noOfReviews;
    }

    public static String getUsername(){
        return username;
    }

    public static String getEmailID(){

        return emailID;
    }

    public static void setEmailID(String emailID){
        imdbTestData.emailID = emailID;
    }

    public static String getPassword(){
        return password;
    }

    public static void setPassword(String password){
        imdbTestData.password = password;
    }

    public static String getReEnterpassword(){
        return reEnterpassword;
    }

    public static void setReEnterpassword(String value){
        imdbTestData.reEnterpassword = reEnterpassword;
    }

    public static String getName(){
        return name;
    }

    public static void setName(String name){
        imdbTestData.name = name;
    }


}
